import sys
import os
import pandas as pd
locate_python = sys.exec_prefix

print(locate_python)

os.system("pause")